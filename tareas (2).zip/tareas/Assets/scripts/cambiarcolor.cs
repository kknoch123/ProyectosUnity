
using UnityEngine;

public class CambiarColor : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;
    private bool colorAlternativo = false;

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            colorAlternativo = !colorAlternativo;

            if (colorAlternativo)
            {
                spriteRenderer.color = Color.red;
            }
            else
            {
                spriteRenderer.color = Color.blue;
            }
        }
    }
}
