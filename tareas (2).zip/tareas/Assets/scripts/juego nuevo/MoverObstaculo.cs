using UnityEngine;

public class MoverObstaculo : MonoBehaviour
{
    public float velocidad = 4f;

    void Update()
    {
        // Se mueven hacia la izquierda constantemente
        transform.Translate(Vector3.left * velocidad * Time.deltaTime);

        // Si se salen mucho de la pantalla por la izquierda, se destruyen para liberar memoria
        if (transform.position.x < -15f)
        {
            Destroy(gameObject);
        }
    }
}