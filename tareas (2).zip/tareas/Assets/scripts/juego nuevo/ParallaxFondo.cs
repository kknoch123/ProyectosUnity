using UnityEngine;

public class ParallaxFondo : MonoBehaviour
{
    public float velocidadParallax; // Velocidad a la que se mueve esta capa
    private float anchoSprite;
    private Vector3 posicionInicial;

    void Start()
    {
        posicionInicial = transform.position;

        // Calculamos el ancho exacto del sprite usando el SpriteRenderer
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer != null)
        {
            anchoSprite = spriteRenderer.bounds.size.x;
        }
    }

    void Update()
    {
        // Desplazamos el fondo hacia la izquierda (simulando avance hacia la derecha)
        transform.Translate(Vector3.left * velocidadParallax * Time.deltaTime);

        // Si el fondo se desplazó completamente fuera de la pantalla, lo regresamos a la derecha para crear el bucle infinito
        if (transform.position.x < posicionInicial.x - anchoSprite)
        {
            transform.position = new Vector3(posicionInicial.x + anchoSprite, transform.position.y, transform.position.z);
        }
    }
}