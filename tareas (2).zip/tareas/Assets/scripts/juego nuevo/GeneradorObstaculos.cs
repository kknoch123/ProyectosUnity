using UnityEngine;

public class GeneradorObstaculos : MonoBehaviour
{
    public GameObject obstaculoPrefab; // Arrastra aquí tu prefab de la barrera
    public float tiempoSpawn = 2.0f;   // Cada cuántos segundos sale un nuevo obstáculo
    public float alturaMin = -2f;      // Altura mínima donde puede aparecer
    public float alturaMax = 2f;       // Altura máxima donde puede aparecer

    private float temporizador = 0f;

    void Update()
    {
        temporizador += Time.deltaTime;

        if (temporizador >= tiempoSpawn)
        {
            Generar();
            temporizador = 0f;
        }
    }

    void Generar()
    {
        // Define una altura aleatoria dentro del rango
        float alturaY = Random.Range(alturaMin, alturaMax);
        Vector3 posicionSpawn = new Vector3(transform.position.x, alturaY, 0);

        // Crea el obstáculo en la posición del generador
        Instantiate(obstaculoPrefab, posicionSpawn, Quaternion.identity);
    }
}