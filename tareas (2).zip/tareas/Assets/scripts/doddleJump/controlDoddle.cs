using UnityEngine;
using UnityEngine.SceneManagement; // Necesario para reiniciar la escena

[RequireComponent(typeof(Rigidbody2D))]
public class controldoddle : MonoBehaviour
{
    [Header("Movimiento")]
    public float moveSpeed = 8f;
    private float moveInput;

    [Header("Salto")]
    public float jumpForce = 12f;

    [Header("Game Over por Caída")]
    public float fallThreshold = 7f; // Distancia por debajo de la cámara para perder
    private Transform mainCameraTransform;

    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        // Encontramos la cámara principal automáticamente
        if (Camera.main != null)
        {
            mainCameraTransform = Camera.main.transform;
        }
    }

    void Update()
    {
        // Leer el movimiento horizontal (Teclas A/D o Flechas)
        moveInput = Input.GetAxisRaw("Horizontal");

        // Comprobar si el jugador cae demasiado por debajo de la cámara
        CheckGameOver();
    }

    void FixedUpdate()
    {
        // Aplicar velocidad horizontal manteniendo la velocidad vertical actual
        rb.linearVelocity = new Vector2(moveInput * moveSpeed, rb.linearVelocity.y);
    }

    // Usamos OnCollisionEnter2D para detectar cuando cae sobre una plataforma sólida
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Comprobar si tocó la plataforma y si el personaje va cayendo (velocidad en Y menor o igual a 0.1)
        if (collision.gameObject.CompareTag("Platform") && rb.linearVelocity.y <= 0.1f)
        {
            // Resetear la velocidad vertical y aplicar el impulso hacia arriba
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0f);
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
        }
    }

    void CheckGameOver()
    {
        if (mainCameraTransform != null)
        {
            // Si la posición Y del jugador es menor que la de la cámara menos el umbral
            if (transform.position.y < mainCameraTransform.position.y - fallThreshold)
            {
                // Reinicia la escena actual para volver a empezar
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }
        }
    }
}