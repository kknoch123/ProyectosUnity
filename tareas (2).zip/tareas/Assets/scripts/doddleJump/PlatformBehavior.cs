using UnityEngine;

public class PlatformBehavior : MonoBehaviour
{
    [Header("Elige el tipo de movimiento")]
    public bool usarMovimientoTransform = true; // Si es true se mueve con Transform, si es false usa linearVelocity

    [Header("Configuración Transform (Ida y Vuelta)")]
    public float speedTransform = 3f;
    public float distanceTransform = 3f;
    private float startX;

    [Header("Configuración Lineal (Rigidbody2D)")]
    public float moveSpeedLinear = 2f;
    public float limitXLinear = 3f;
    private Rigidbody2D rbPlatform;
    private int direction = 1;

    void Start()
    {
        startX = transform.position.x;

        // Configuración si usa Rigidbody lineal
        if (!usarMovimientoTransform)
        {
            rbPlatform = GetComponent<Rigidbody2D>();
            if (rbPlatform == null)
            {
                rbPlatform = gameObject.AddComponent<Rigidbody2D>();
            }
            rbPlatform.bodyType = RigidbodyType2D.Kinematic; // Kinematic para que no caiga por gravedad
        }
    }

    void Update()
    {
        // Opción 1: Movimiento suave con Transform (ideal para plataformas móviles sencillas)
        if (usarMovimientoTransform)
        {
            float newX = startX + Mathf.Sin(Time.time * speedTransform) * distanceTransform;
            transform.position = new Vector3(newX, transform.position.y, transform.position.z);
        }
    }

    void FixedUpdate()
    {
        // Opción 2: Movimiento lineal usando linearVelocity
        if (!usarMovimientoTransform && rbPlatform != null)
        {
            rbPlatform.linearVelocity = new Vector2(moveSpeedLinear * direction, 0f);

            // Cambiar dirección al llegar al límite
            if (transform.position.x > startX + limitXLinear)
            {
                direction = -1;
            }
            else if (transform.position.x < startX - limitXLinear)
            {
                direction = 1;
            }
        }
    }
}