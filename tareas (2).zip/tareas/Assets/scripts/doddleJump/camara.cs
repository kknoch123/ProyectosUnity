using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target; // Arrastra tu GameObject "Player" aquí en el Inspector

    void LateUpdate()
    {
        if (target == null) return;

        // Solo movemos la cámara hacia arriba si el jugador supera la posición Y de la cámara
        if (target.position.y > transform.position.y)
        {
            Vector3 newPos = new Vector3(transform.position.x, target.position.y, transform.position.z);
            transform.position = newPos;
        }
    }
}