using UnityEngine;

public class LevelGenerator : MonoBehaviour
{
    [Header("Prefabs de Plataformas")]
    public GameObject[] platformPrefabs; // Arrastra aquí tanto la normal como la móvil en el Inspector

    [Header("Configuración del Nivel")]
    public int numberOfPlatforms = 15;
    public float levelWidth = 3f;
    public float minY = 3f;
    public float maxY = 5f;
    public float startYHeight = 3f;

    void Start()
    {
        if (platformPrefabs == null || platformPrefabs.Length == 0)
        {
            Debug.LogError("¡No hay prefabs asignados en el LevelGenerator!");
            return;
        }

        float currentYPosition = startYHeight;
        Vector3 spawnPosition = new Vector3();

        for (int i = 0; i < numberOfPlatforms; i++)
        {
            currentYPosition += Random.Range(minY, maxY);
            spawnPosition.y = currentYPosition;
            spawnPosition.x = Random.Range(-levelWidth, levelWidth);

            // Elegir un prefab al azar del arreglo (estática o móvil)
            int randomIndex = Random.Range(0, platformPrefabs.Length);
            GameObject selectedPlatform = platformPrefabs[randomIndex];

            // Instanciar la plataforma elegida aleatoriamente
            Instantiate(selectedPlatform, spawnPosition, Quaternion.identity);
        }
    }
}