using UnityEngine;
using UnityEngine.SceneManagement; // Necesario para reiniciar la escena/nivel

public class ControlJugador : MonoBehaviour
{
    public float fuerzaSalto = 5f;
    public float velocidadAvance = 3f;
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
       
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, fuerzaSalto);
        }
    }

    void FixedUpdate()
    {
        
        rb.linearVelocity = new Vector2(velocidadAvance, rb.linearVelocity.y);
    }

    private void OnCollisionEnter2D(Collision2D colision)
    {
       
        if (colision.gameObject.CompareTag("Obstaculo") || colision.gameObject.name.Contains("Square"))
        {
            ReiniciarJuego();
        }
    }

    
    private void OnTriggerEnter2D(Collider2D otro)
    {
        if (otro.CompareTag("Obstaculo") || otro.name.Contains("Square"))
        {
            ReiniciarJuego();
        }
    }

    void ReiniciarJuego()
    {
    
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}